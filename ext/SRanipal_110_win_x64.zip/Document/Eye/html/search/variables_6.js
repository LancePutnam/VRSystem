var searchData=
[
  ['sensitive_5ffactor',['sensitive_factor',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_gaze_ray_parameter.html#a962a7531779c27b0f9145401ce885f24',1,'ViveSR::anipal::Eye::GazeRayParameter']]]
];
