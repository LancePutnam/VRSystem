var searchData=
[
  ['getstatus',['GetStatus',['../namespace_vive_s_r_1_1anipal.html#a0b5cf88515072242a93ec853327955e3',1,'ViveSR::anipal']]]
];
