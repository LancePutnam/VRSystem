var searchData=
[
  ['eye_5fdata_5fvalidata_5fbit_5fmask',['eye_data_validata_bit_mask',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_single_eye_data.html#a93686414a7556eb88a023f055e35b5a0',1,'ViveSR::anipal::Eye::SingleEyeData']]],
  ['eye_5fopenness',['eye_openness',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_single_eye_data.html#a1c877b0b76d7a6ca95e332764c38c4af',1,'ViveSR::anipal::Eye::SingleEyeData']]]
];
