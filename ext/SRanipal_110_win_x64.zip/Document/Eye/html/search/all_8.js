var searchData=
[
  ['pupil_5fdiameter_5fmm',['pupil_diameter_mm',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_single_eye_data.html#a0c795e5a188c58e15ae2e3a396f80496',1,'ViveSR::anipal::Eye::SingleEyeData']]],
  ['pupil_5fposition_5fin_5fsensor_5farea',['pupil_position_in_sensor_area',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_single_eye_data.html#ac81c6430f61ece68efc6efb645edc8c5',1,'ViveSR::anipal::Eye::SingleEyeData']]]
];
